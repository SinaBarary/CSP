public class Main {
    public static void main(String[] args) {

        //Region name's :
        String[] D_City = {"Norrbotten", "Vasterbotten", "Vasternorralnd", "Jamtland", "Gavleborg", "Dalarna", "Varmland"
                , "Orebro", "Vastmanland", "Uppsala", "Stockholm", "Sodermanland", "Ostergotland", "VastraGotland"
                , "Jonkoping", "kalmar", "Gotland", "Halland", "Koronoberge", "Blokinge", "Skane"};

        /* Region's index :
        Norrbotten = 0, Vasterbotten = 1, Vasternorralnd = 2,Jamtland = 3,Gavleborg = 4
        ,Dalarna = 5, Varmland = 6, Orebro = 7, Vastmanland = 8, Uppsala = 9, Stockholm = 10
        , Sodermanland  = 11, Ostergotland  = 12, VastraGotland = 13, Jonkoping = 14,
         kalmar = 15, Gotland  = 16, Halland = 17, Koronoberge = 18, Blokinge = 19,  Skane = 20
         */
        int[][] Graph_Region = {
                // 0                  1                  2
                //0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0
                {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //0
                {1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //1
                {0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //2
                {0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //3
                {0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //4
                {0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //5
                {0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0},   //6
                {0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0},   //7
                {0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //8
                {0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //9
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //10
                {0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0},   //11
                {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0},   //12
                {0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0},   //13
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0},   //14
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0},   //15
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   //16
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1},   //17
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1},   //18
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1},   //19
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0}};  //20
        /* تست برای اینکه ببینیم تعداد قید ها را به درستی نوشتیم یا خیر
        int count = 0;
        for (int i = 0; i< Graph_Region.length; i++)
            for (int j = 0; j< Graph_Region.length; j++)
                if (Graph_Region[i][j] == 1)
                    count++;
        System.out.print(count);
        */


        //قيود
        /* Ci = { Norrbotten != Vasterbotten \\ Vasternorralnd != Vasterbotten \\ Jamtland != Vasterbotten
                  Jamtland != Vasternorralnd \\ Vasternorralnd != Gavleborg \\ Jamtland != Gavleborg \\
                  Jamtland != Dalarna \\ Gavleborg != Dalarna \\ Gavleborg != Uppsala \\
                  Gavleborg != Vastmanland \\ Uppsala != Stockholm \\ Uppsala != Vastmanland \\
                  Dalarna != Varmland \\ Dalarna != Orebro \\ Dalarna != Vastmanland \\
                  Varmland != VastraGotland \\ Varmland != Orebro \\ Orebro != Vastmanland \\
                  Orebro != Sodermanland \\ Orebro != Ostergotland \\ Orebro != VastraGotland \\
                  Vastmanland != Sodermanland \\ Stockholm != Sodermanland \\ Sodermanland != Ostergotland \\
                  Ostergotland != kalmar \\ Ostergotland != Jonkoping \\ VastraGotland != Jonkoping \\
                  VastraGotland != Halland \\ Jonkoping != Halland \\ Jonkoping != Koronoberge \\
                  Jonkoping != kalmar \\ kalmar != Koronoberge \\ kalmar != Blokinge \\
                  Halland != Skane \\ Halland != Koronoberge \\ Koronoberge != Skane \\
                  Koronoberge != Blokinge \\ Blokinge != Skane \\
                  Gotland does not have a neighborhood;
                } */

        //Color's :
        int[] X_Color = {1, 2, 3, 4};
        String[] color_name = {"Red", "Blue", "Green", "Yellow"};

        //Region's Color :
        int[] City_Color = new int[D_City.length];

        //Found City's color
        int[] MRV = new int[21];
        int Most_Priority_Riegon = 0;
        MRV = FindMRV(MRV, Graph_Region, City_Color);
        Most_Priority_Riegon = FindMostPriRiegon(MRV, Most_Priority_Riegon, Graph_Region);
        MRV(Graph_Region, X_Color, City_Color, MRV, Most_Priority_Riegon);

        //Out
        for (int i = 0; i < D_City.length; i++) {
            switch (City_Color[i]) {
                case 1:
                    System.out.println(D_City[i] + " color is :" + color_name[0]);
                    break;
                case 2:
                    System.out.println(D_City[i] + " color is :" + color_name[1]);
                    break;
                case 3:
                    System.out.println(D_City[i] + " color is :" + color_name[2]);
                    break;
                case 4:
                    System.out.println(D_City[i] + " color is :" + color_name[3]);
                    break;
            }
        }

    }

    //Use Degree and Find Most Priority Region
    private static int FindMostPriRiegon(int[] MRV, int Most_Priority_Riegon, int[][] graphRegion) {
        for (int i = 0; i < 21; i++) {
            if (MRV[i] > MRV[Most_Priority_Riegon])
                Most_Priority_Riegon = i;
            else if (MRV[i] == MRV[Most_Priority_Riegon]) {
                Most_Priority_Riegon = Degree(graphRegion, Most_Priority_Riegon, i);
            }
        }
        return Most_Priority_Riegon;
    }

    private static int[] FindMRV(int[] mrv, int[][] graphRegion, int[] cityColor) {
        //Find MRV
        for (int i = 0; i < graphRegion.length; i++) {
            if (cityColor[i] == 0){
                mrv[i] = 0;
                for (int j = 0; j < graphRegion.length; j++) {
                    if (graphRegion[i][j] == 1 && cityColor[j] != 0) {
                        mrv[i] += 1;
                    }
                }
            }
        }
        return mrv;
    }

    //مقدار دادن رنگی با کمترین محدودیت به متغیر به طوری که در مراحل بعدی به جایی نرسیم که دیگر نتوانیم مقدار بدهیم
    private static void LCV(int[][] graphRegion, int[] xColor, int[] cityColor, int most_Priority_Riegon) {
        boolean[] Cannot_be = new boolean[4];

        for (int i = 0; i < graphRegion.length; i++) {
            if (graphRegion[most_Priority_Riegon][i] == 1) {
                if (cityColor[i] == xColor[0])
                    Cannot_be[0] = true;
                else if (cityColor[i] == xColor[1]) {
                    Cannot_be[1] = true;
                } else if (cityColor[i] == xColor[2]) {
                    Cannot_be[2] = true;
                } else if (cityColor[i] == xColor[3]) {
                    Cannot_be[3] = true;
                }
            }
        }
        for (int i = 0; i < Cannot_be.length; i++) {
            if (!Cannot_be[i]) {
                cityColor[most_Priority_Riegon] = xColor[i];
                return;
            }
        }
    }

    //متغیر هایی که به آن ها مقدار داده نشده و بیشترین قید را دارند
    //برای این میبینیم کدوم متغیر بیشترین قید رو داره
    //فقط تعداد همسایه ها
    private static int Degree(int[][] graphRegion, int MRV_F_index, int MRV_S_index) {
        int degree_index;
        int Deg_F = 0, Deg_S = 0;
        for (int i = 0; i < graphRegion.length; i++) {
            if (graphRegion[MRV_F_index][i] == 1)
                Deg_F += 1;
            if (graphRegion[MRV_S_index][i] == 1)
                Deg_S += 1;
        }
        if (Deg_F >= Deg_S)
            degree_index = MRV_F_index;
        else
            degree_index = MRV_S_index;

        return degree_index;
    }

    //انتخاب متغیری که با کمترین مقدار انتساب ممکن
    // متغیری که کمترین رنگ را بتوان به ان انتساب داد
    //برای این میبینیم کدوم متغیر ها میتونه کمترین رنگ رو داشته باشه
    //تعداد همسایه های رنگی اولویت دارد
    private static void MRV(int[][] graphRegion, int[] xColor, int[] cityColor, int[] MRV, int Most_Priority_Riegon) {

        MRV = FindMRV(MRV,graphRegion,cityColor);
        Most_Priority_Riegon = FindMostPriRiegon(MRV,Most_Priority_Riegon,graphRegion);

        LCV(graphRegion, xColor, cityColor, Most_Priority_Riegon);
        MRV[Most_Priority_Riegon] = -1;
        if (ALLHomeColored(cityColor))
            return;
        MRV(graphRegion, xColor, cityColor, MRV, Most_Priority_Riegon);
    }

    private static boolean ALLHomeColored(int[] cityColor) {
        int count_color = 0;
        for (int i =0; i< cityColor.length;i++)
            if (cityColor[i] != 0)
                count_color += 1;
        if (count_color == cityColor.length)
            return true;
        else
            return false;
    }
}